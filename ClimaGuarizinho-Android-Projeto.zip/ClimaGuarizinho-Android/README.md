# Clima Guarizinho — Android

Projeto Android nativo (Java + WebView) que empacota a interface HTML original do Clima Guarizinho e consulta a previsão em tempo real pela API Open-Meteo.

## O que está incluído
- Interface original em tema escuro/claro, responsiva.
- Condições atuais, próximas 12 horas e previsão de 7 dias.
- Atualização automática a cada 30 minutos e cache local da última consulta.
- Aplicativo Android instalável, com ícone e nome próprios.

## Localização meteorológica
Coordenadas aproximadas do núcleo de Guarizinho: -23.71303, -48.85277 (Itapeva/SP). A previsão é regional, não uma medição dentro de um endereço específico.

## Gerar APK
Abra a pasta no Android Studio (JDK 17 e Android SDK 35), aguarde a sincronização do Gradle e execute **Build > Build Bundle(s) / APK(s) > Build APK(s)**. O APK de depuração ficará em `app/build/outputs/apk/debug/app-debug.apk`.

Também há workflow em `.github/workflows/android.yml`: envie este projeto para um repositório GitHub e execute o workflow para compilar o APK automaticamente.

## API e atribuição
A previsão usa Open-Meteo: https://open-meteo.com/en/docs. Para uso comercial, confira os termos e opções de licença da Open-Meteo. A conexão com internet é necessária para atualizar; a última previsão consultada fica em cache no aparelho.
